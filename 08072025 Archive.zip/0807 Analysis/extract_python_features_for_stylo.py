#!/usr/bin/env python3
"""
Extract comprehensive features using our Python analysis, then export for Stylo
"""

import sys
import os
import pandas as pd
import numpy as np

# Add the src directory to Python path
sys.path.append('/home/user/greek-manuscript-comparison/src')

from multi_comparison import MultipleManuscriptComparison

def collect_manuscripts_by_book(data_dir: str) -> dict:
    """Collect manuscripts like the original analysis"""
    # Same function as in run_nlp_analysis.py
    book_name_mapping = {
        '070_MAT': 'Matthew', '071_MRK': 'Mark', '072_LUK': 'Luke', '073_JHN': 'John', '074_ACT': 'Acts',
        '075_ROM': 'Romans', '076_1CO': '1Corinthians', '077_2CO': '2Corinthians', '078_GAL': 'Galatians',
        '079_EPH': 'Ephesians', '080_PHP': 'Philippians', '081_COL': 'Colossians', '082_1TH': '1Thessalonians',
        '083_2TH': '2Thessalonians', '084_1TI': '1Timothy', '085_2TI': '2Timothy', '086_TIT': 'Titus',
        '087_PHM': 'Philemon', '088_HEB': 'Hebrews', '089_JAS': 'James', '090_1PE': '1Peter', '091_2PE': '2Peter',
        '092_1JN': '1John', '093_2JN': '2John', '094_3JN': '3John', '095_JUD': 'Jude', '096_REV': 'Revelation'
    }
    
    julian_name_mapping = {
        'Διονυσίῳ.txt': 'Julian_To_Dionysius',
        'Λιβανίῳ σοφιστῇ καὶ κοιαίστωρι.txt': 'Julian_To_Libanius_the_Sophist',
        'Σαραπίωνι τῷ λαμπροτάτῳ.txt': 'Julian_To_Sarapion_the_Most_Illustrious',
        'Τῷ αὐτῷ.txt': 'Julian_To_the_Same_Person',
        'φραγμεντυμ επιστολαε.txt': 'Julian_Letter_Fragment',
        'Ἀνεπίγραφος ὑπὲρ Ἀργείων.txt': 'Julian_Untitled_Letter_about_the_Argives'
    }
    
    manuscripts = {}
    
    # Process biblical texts
    chapter_files = {}
    for root, dirs, files in os.walk(data_dir):
        if 'Julian' in root:
            continue
        for file in files:
            if file.endswith('.txt') and '_read' in file:
                full_path = os.path.join(root, file)
                name = file.replace('_read.txt', '').replace('grcsbl_', '')
                parts = name.split('_')
                if len(parts) >= 2:
                    book_key = f"{parts[0]}_{parts[1]}"
                    if book_key not in chapter_files:
                        chapter_files[book_key] = []
                    chapter_files[book_key].append(full_path)
    
    # Combine chapters into complete books
    for book_key, file_paths in chapter_files.items():
        file_paths.sort(key=lambda x: int(x.split('_')[-2]))
        combined_text = ""
        for file_path in file_paths:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    chapter_text = f.read().strip()
                    if chapter_text:
                        combined_text += chapter_text + "\n\n"
            except Exception as e:
                print(f"Warning: Could not read {file_path}: {e}")
        
        if combined_text.strip():
            readable_name = book_name_mapping.get(book_key, book_key)
            manuscripts[readable_name] = combined_text.strip()
    
    # Process Julian's letters
    julian_dir = os.path.join(data_dir, 'Julian')
    if os.path.exists(julian_dir):
        for file in os.listdir(julian_dir):
            if file.endswith('.txt'):
                file_path = os.path.join(julian_dir, file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            readable_name = julian_name_mapping.get(file, f"Julian_{file.replace('.txt', '')}")
                            manuscripts[readable_name] = text
                except Exception as e:
                    print(f"Warning: Could not read Julian letter {file}: {e}")
    
    return manuscripts

def main():
    """Extract comprehensive features and export for Stylo"""
    print("=== Extracting Python Features for Stylo ===")
    
    # Collect manuscripts using same method as original analysis
    data_dir = "/home/user/greek-manuscript-comparison/data"
    manuscripts = collect_manuscripts_by_book(data_dir)
    
    print(f"Found {len(manuscripts)} manuscripts")
    
    # Initialize the comparison system
    comparator = MultipleManuscriptComparison(use_advanced_nlp=True)
    
    # Prepare texts
    manuscript_texts = list(manuscripts.values())
    manuscript_names = list(manuscripts.keys())
    
    # Extract comprehensive features
    print("Extracting comprehensive features...")
    processed_manuscripts = comparator.preprocess_manuscripts(manuscript_texts, manuscript_names)
    features_data = comparator.extract_features(processed_manuscripts)
    
    # Get the feature matrices (this is the 1,208-dimensional data)
    print(f"Feature matrices shape: {len(comparator.feature_matrices)} x {len(comparator.feature_matrices[0])}")
    
    # Convert to DataFrame for Stylo
    feature_df = pd.DataFrame(
        comparator.feature_matrices,
        index=comparator.manuscript_names
    )
    
    # Save as CSV for Stylo import
    feature_df.to_csv('/home/user/Stylo/python_features.csv')
    
    print(f"Exported {feature_df.shape[0]} manuscripts x {feature_df.shape[1]} features to python_features.csv")
    print("Ready for Stylo import!")

if __name__ == "__main__":
    main()