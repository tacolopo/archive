#!/usr/bin/env python3

import sys
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List
import json

sys.path.insert(0, '.')

from src.multi_comparison import MultipleManuscriptComparison
from src.preprocessing import GreekTextPreprocessor
from src.features import FeatureExtractor
from src.similarity import SimilarityCalculator

CLUSTER_0_MANUSCRIPTS = [
    "1 Corinthians", "1 John", "1 Peter", "1 Thessalonians", "1 Timothy",
    "2 Corinthians", "2 John", "2 Peter", "2 Thessalonians", "2 Timothy", 
    "3 John", "Galatians", "Hebrews", "James", "Jude",
    "Julian: Letter Fragment", "Julian: To Dionysius", "Julian: To Libanius the Sophist",
    "Julian: To Sarapion the Most Illustrious", "Julian: To the Same Person",
    "Julian: Untitled Letter about the Argives", "Philemon", "Philippians",
    "Revelation", "Romans", "Titus"
]

def load_manuscripts():
    manuscripts = {}
    
    paul_dir = "data/Cleaned_Paul_Texts"
    if os.path.exists(paul_dir):
        for filename in os.listdir(paul_dir):
            if filename.endswith('_read.txt'):
                if 'grcsbl_075_ROM' in filename:
                    book = 'Romans'
                elif 'grcsbl_076_1CO' in filename:
                    book = '1 Corinthians'
                elif 'grcsbl_077_2CO' in filename:
                    book = '2 Corinthians'
                elif 'grcsbl_078_GAL' in filename:
                    book = 'Galatians'
                elif 'grcsbl_080_PHP' in filename:
                    book = 'Philippians'
                elif 'grcsbl_082_1TH' in filename:
                    book = '1 Thessalonians'
                elif 'grcsbl_083_2TH' in filename:
                    book = '2 Thessalonians'
                elif 'grcsbl_084_1TI' in filename:
                    book = '1 Timothy'
                elif 'grcsbl_085_2TI' in filename:
                    book = '2 Timothy'
                elif 'grcsbl_086_TIT' in filename:
                    book = 'Titus'
                elif 'grcsbl_087_PHM' in filename:
                    book = 'Philemon'
                else:
                    continue
                
                if book not in manuscripts:
                    manuscripts[book] = []
                
                with open(os.path.join(paul_dir, filename), 'r', encoding='utf-8') as f:
                    manuscripts[book].append(f.read())
    
    complete_manuscripts = {}
    for book, chapters in manuscripts.items():
        complete_manuscripts[book] = ' '.join(chapters)
    
    julian_dir = "data/Julian_backup"
    if os.path.exists(julian_dir):
        julian_mapping = {
            'Διονυσίῳ.txt': 'Julian: To Dionysius',
            'Λιβανίῳ σοφιστῇ καὶ κοιαίστωρι.txt': 'Julian: To Libanius the Sophist',
            'Σαραπίωνι τῷ λαμπροτάτῳ.txt': 'Julian: To Sarapion the Most Illustrious',
            'Τῷ αὐτῷ.txt': 'Julian: To the Same Person',
            'φραγμεντυμ επιστολαε.txt': 'Julian: Letter Fragment',
            'Ἀνεπίγραφος ὑπὲρ Ἀργείων.txt': 'Julian: Untitled Letter about the Argives'
        }
        
        for filename, name in julian_mapping.items():
            filepath = os.path.join(julian_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    complete_manuscripts[name] = f.read()
    
    nt_dir = "data/Non-Pauline Texts"
    if os.path.exists(nt_dir):
        nt_books = {}
        for filename in os.listdir(nt_dir):
            if filename.endswith('_read.txt'):
                if 'grcsbl_088_HEB' in filename:
                    book = 'Hebrews'
                elif 'grcsbl_089_JAS' in filename:
                    book = 'James'
                elif 'grcsbl_090_1PE' in filename:
                    book = '1 Peter'
                elif 'grcsbl_091_2PE' in filename:
                    book = '2 Peter'
                elif 'grcsbl_092_1JN' in filename:
                    book = '1 John'
                elif 'grcsbl_093_2JN' in filename:
                    book = '2 John'
                elif 'grcsbl_094_3JN' in filename:
                    book = '3 John'
                elif 'grcsbl_095_JUD' in filename:
                    book = 'Jude'
                elif 'grcsbl_096_REV' in filename:
                    book = 'Revelation'
                else:
                    continue
                
                if book in CLUSTER_0_MANUSCRIPTS:
                    if book not in nt_books:
                        nt_books[book] = []
                    
                    with open(os.path.join(nt_dir, filename), 'r', encoding='utf-8') as f:
                        nt_books[book].append(f.read())
        
        for book, chapters in nt_books.items():
            complete_manuscripts[book] = ' '.join(chapters)
    
    return complete_manuscripts

def run_real_analysis():
    print("Loading actual manuscript data...")
    manuscripts = load_manuscripts()
    
    cluster0_data = {name: text for name, text in manuscripts.items() 
                     if name in CLUSTER_0_MANUSCRIPTS and len(text.strip()) > 100}
    
    print(f"Found {len(cluster0_data)} Cluster 0 manuscripts:")
    for name in sorted(cluster0_data.keys()):
        print(f"  - {name} ({len(cluster0_data[name])} chars)")
    
    if len(cluster0_data) < 3:
        print("Not enough manuscripts found!")
        return None
    
    print("\nRunning NLP analysis...")
    comparator = MultipleManuscriptComparison(use_advanced_nlp=False)
    
    try:
        processed_manuscripts = {}
        for name, text in cluster0_data.items():
            print(f"Processing {name}...")
            preprocessed = comparator.preprocessor.preprocess(text)
            preprocessed['nlp_features'] = {}
            processed_manuscripts[name] = preprocessed
        
        print("Extracting features...")
        features_data = comparator.extract_features(processed_manuscripts)
        
        print("Calculating similarity matrices...")
        similarities = comparator.similarity_calculator.calculate_multiple_similarities(
            comparator.feature_matrices, comparator.manuscript_names
        )
        
        return {
            'manuscript_names': comparator.manuscript_names,
            'similarity_matrices': similarities,
            'features_data': features_data,
            'feature_matrices': comparator.feature_matrices
        }
        
    except Exception as e:
        print(f"Error during analysis: {e}")
        import traceback
        traceback.print_exc()
        return None

def create_real_similarity_charts(results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    manuscript_names = results['manuscript_names']
    similarity_matrices = results['similarity_matrices']
    
    if 'cosine' in similarity_matrices:
        sim_matrix = similarity_matrices['cosine']
        metric_name = 'Cosine Similarity'
    else:
        sim_matrix = list(similarity_matrices.values())[0]
        metric_name = 'Similarity'
    
    print(f"Creating charts for {len(manuscript_names)} manuscripts")
    print(f"Similarity matrix shape: {sim_matrix.shape}")
    
    stats_data = []
    for i, manuscript in enumerate(manuscript_names):
        row_similarities = sim_matrix[i, :]
        other_similarities = np.concatenate([row_similarities[:i], row_similarities[i+1:]])
        
        max_sim_idx = np.argmax(other_similarities)
        if max_sim_idx >= i:
            max_sim_idx += 1
        
        stats_data.append({
            'Manuscript': manuscript,
            'Mean Similarity': other_similarities.mean(),
            'Max Similarity': other_similarities.max(),
            'Min Similarity': other_similarities.min(),
            'Std Similarity': other_similarities.std(),
            'Most Similar To': manuscript_names[max_sim_idx]
        })
    
    stats_df = pd.DataFrame(stats_data)
    stats_df = stats_df.sort_values('Mean Similarity', ascending=False)
    
    csv_file = os.path.join(output_dir, 'real_cluster0_similarities.csv')
    stats_df.to_csv(csv_file, index=False)
    
    plt.figure(figsize=(12, 10))
    
    mask = np.triu(np.ones_like(sim_matrix, dtype=bool), k=1)
    
    sns.heatmap(sim_matrix,
                xticklabels=manuscript_names,
                yticklabels=manuscript_names,
                annot=True,
                fmt='.3f',
                cmap='RdYlBu_r',
                center=0.5,
                square=True,
                mask=mask,
                cbar_kws={'label': 'Similarity Score'})
    
    plt.title('Cluster 0 Cosine Similarity', 
              fontsize=14, fontweight='bold', pad=20)
    plt.xlabel('Manuscripts', fontsize=12)
    plt.ylabel('Manuscripts', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    
    heatmap_file = os.path.join(output_dir, 'real_cluster0_heatmap.png')
    plt.savefig(heatmap_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    plt.figure(figsize=(12, 8))
    plt.axis('tight')
    plt.axis('off')
    
    display_data = stats_df.head(10).round(3)
    
    table = plt.table(cellText=display_data.values,
                     colLabels=display_data.columns,
                     cellLoc='center',
                     loc='center',
                     bbox=[0, 0, 1, 1])
    
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.5)
    
    for i in range(len(display_data.columns)):
        table[(0, i)].set_facecolor('#4CAF50')
        table[(0, i)].set_text_props(weight='bold', color='white')
    
    plt.title('Real Cluster 0: Top 10 Most Similar Manuscripts\\n(Based on Actual Linguistic Features)', 
              fontsize=14, fontweight='bold', pad=20)
    
    table_file = os.path.join(output_dir, 'real_cluster0_statistics.png')
    plt.savefig(table_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"\\nReal similarity analysis complete!")
    print(f"Results saved to: {output_dir}/")
    print(f"CSV data: {csv_file}")
    print(f"Heatmap: {heatmap_file}")
    print(f"Statistics: {table_file}")
    
    return stats_df

def main():
    print("EXTRACTING REAL CLUSTER 0 SIMILARITY DATA")
    print("=" * 50)
    
    results = run_real_analysis()
    
    if results is None:
        print("Failed to run analysis. Check errors above.")
        return
    
    output_dir = "real_cluster0_similarities"
    stats_df = create_real_similarity_charts(results, output_dir)
    
    print("\\nTop 5 most similar manuscripts:")
    print(stats_df.head()[['Manuscript', 'Mean Similarity', 'Most Similar To']].to_string(index=False))
    
    print("\\nThis uses REAL linguistic features extracted from the actual Greek manuscripts!")

if __name__ == "__main__":
    main() 