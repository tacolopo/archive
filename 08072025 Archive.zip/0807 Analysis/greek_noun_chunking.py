#!/usr/bin/env python3

import spacy

class GreekNounChunker:
    
    def __init__(self):
        try:
            self.nlp = spacy.load("grc_odycy_joint_sm")
        except Exception as e:
            raise RuntimeError(f"Ancient Greek spaCy model required: {e}")
    
    def extract_noun_chunks(self, text):
        doc = self.nlp(text)
        return self._extract_custom_noun_chunks(doc)
    
    def _extract_custom_noun_chunks(self, doc):
        chunks = []
        
        i = 0
        while i < len(doc):
            token = doc[i]
            
            if token.pos_ in ['PUNCT', 'SPACE']:
                i += 1
                continue
            
            chunk_tokens = []
            
            if token.pos_ == 'DET':
                chunk_tokens.append(token)
                j = i + 1
                
                while j < len(doc) and doc[j].pos_ == 'ADJ':
                    chunk_tokens.append(doc[j])
                    j += 1
                
                if j < len(doc) and doc[j].pos_ == 'NOUN':
                    chunk_tokens.append(doc[j])
                    j += 1
                
                if len(chunk_tokens) >= 2:
                    chunk_text = ' '.join([t.text for t in chunk_tokens])
                    chunks.append(chunk_text)
                    i = j
                    continue
            
            elif token.pos_ == 'ADJ':
                chunk_tokens.append(token)
                j = i + 1
                
                while j < len(doc) and doc[j].pos_ == 'ADJ':
                    chunk_tokens.append(doc[j])
                    j += 1
                
                if j < len(doc) and doc[j].pos_ == 'NOUN':
                    chunk_tokens.append(doc[j])
                    j += 1
                    
                    chunk_text = ' '.join([t.text for t in chunk_tokens])
                    chunks.append(chunk_text)
                    i = j
                    continue
            
            elif token.pos_ == 'NOUN':
                chunk_tokens.append(token)
                j = i + 1
                
                while j < len(doc) and doc[j].pos_ in ['NOUN', 'PRON'] and 'Gen' in doc[j].tag_:
                    chunk_tokens.append(doc[j])
                    j += 1
                
                if len(chunk_tokens) >= 2:
                    chunk_text = ' '.join([t.text for t in chunk_tokens])
                    chunks.append(chunk_text)
                    i = j
                    continue
                else:
                    chunks.append(token.text)
            
            elif token.pos_ == 'PRON':
                chunks.append(token.text)
            
            i += 1
        
        return chunks

def process_greek_text(text):
    chunker = GreekNounChunker()
    return chunker.extract_noun_chunks(text)

if __name__ == "__main__":
    with open("../data/Julian/Διονυσίῳ.txt", "r", encoding="utf-8") as f:
        sample_text = f.read()[:200]
    chunks = process_greek_text(sample_text)
    print("Extracted noun chunks:", len(chunks))