#!/usr/bin/env python3

import sys
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List
import json

sys.path.insert(0, '.')

from src.multi_comparison import MultipleManuscriptComparison
from src.preprocessing import GreekTextPreprocessor
from src.features import FeatureExtractor
from src.similarity import SimilarityCalculator

CLUSTER_0_MANUSCRIPTS = [
    "1 Corinthians", "1 John", "1 Peter", "1 Thessalonians", "1 Timothy",
    "2 Corinthians", "2 John", "2 Peter", "2 Thessalonians", "2 Timothy", 
    "3 John", "Galatians", "Hebrews", "James", "Jude",
    "Julian: Letter Fragment", "Julian: To Dionysius", "Julian: To Libanius the Sophist",
    "Julian: To Sarapion the Most Illustrious", "Julian: To the Same Person",
    "Julian: Untitled Letter about the Argives", "Philemon", "Philippians",
    "Revelation", "Romans", "Titus"
]

def load_all_manuscripts():
    manuscripts = {}
    
    paul_dir = "data/Cleaned_Paul_Texts"
    if os.path.exists(paul_dir):
        paul_books = {}
        for filename in os.listdir(paul_dir):
            if filename.endswith('_read.txt'):
                if 'grcsbl_075_ROM' in filename:
                    book = 'Romans'
                elif 'grcsbl_076_1CO' in filename:
                    book = '1 Corinthians'
                elif 'grcsbl_077_2CO' in filename:
                    book = '2 Corinthians'
                elif 'grcsbl_078_GAL' in filename:
                    book = 'Galatians'
                elif 'grcsbl_079_EPH' in filename:
                    book = 'Ephesians'
                elif 'grcsbl_080_PHP' in filename:
                    book = 'Philippians'
                elif 'grcsbl_081_COL' in filename:
                    book = 'Colossians'
                elif 'grcsbl_082_1TH' in filename:
                    book = '1 Thessalonians'
                elif 'grcsbl_083_2TH' in filename:
                    book = '2 Thessalonians'
                elif 'grcsbl_084_1TI' in filename:
                    book = '1 Timothy'
                elif 'grcsbl_085_2TI' in filename:
                    book = '2 Timothy'
                elif 'grcsbl_086_TIT' in filename:
                    book = 'Titus'
                elif 'grcsbl_087_PHM' in filename:
                    book = 'Philemon'
                else:
                    continue
                
                if book not in paul_books:
                    paul_books[book] = []
                
                with open(os.path.join(paul_dir, filename), 'r', encoding='utf-8') as f:
                    paul_books[book].append(f.read())
        
        for book, chapters in paul_books.items():
            manuscripts[book] = ' '.join(chapters)
    
    nt_dir = "data/Non-Pauline Texts"
    if os.path.exists(nt_dir):
        nt_books = {}
        for filename in os.listdir(nt_dir):
            if filename.endswith('_read.txt'):
                if 'grcsbl_070_MAT' in filename:
                    book = 'Matthew'
                elif 'grcsbl_071_MRK' in filename:
                    book = 'Mark'
                elif 'grcsbl_072_LUK' in filename:
                    book = 'Luke'
                elif 'grcsbl_073_JHN' in filename:
                    book = 'John'
                elif 'grcsbl_074_ACT' in filename:
                    book = 'Acts'
                elif 'grcsbl_088_HEB' in filename:
                    book = 'Hebrews'
                elif 'grcsbl_089_JAS' in filename:
                    book = 'James'
                elif 'grcsbl_090_1PE' in filename:
                    book = '1 Peter'
                elif 'grcsbl_091_2PE' in filename:
                    book = '2 Peter'
                elif 'grcsbl_092_1JN' in filename:
                    book = '1 John'
                elif 'grcsbl_093_2JN' in filename:
                    book = '2 John'
                elif 'grcsbl_094_3JN' in filename:
                    book = '3 John'
                elif 'grcsbl_095_JUD' in filename:
                    book = 'Jude'
                elif 'grcsbl_096_REV' in filename:
                    book = 'Revelation'
                else:
                    continue
                
                if book not in nt_books:
                    nt_books[book] = []
                
                with open(os.path.join(nt_dir, filename), 'r', encoding='utf-8') as f:
                    nt_books[book].append(f.read())
        
        for book, chapters in nt_books.items():
            manuscripts[book] = ' '.join(chapters)
    
    julian_dir = "data/Julian_backup"
    if os.path.exists(julian_dir):
        julian_mapping = {
            'Διονυσίῳ.txt': 'Julian: To Dionysius',
            'Λιβανίῳ σοφιστῇ καὶ κοιαίστωρι.txt': 'Julian: To Libanius the Sophist',
            'Σαραπίωνι τῷ λαμπροτάτῳ.txt': 'Julian: To Sarapion the Most Illustrious',
            'Τῷ αὐτῷ.txt': 'Julian: To the Same Person',
            'φραγμεντυμ επιστολαε.txt': 'Julian: Letter Fragment',
            'Ἀνεπίγραφος ὑπὲρ Ἀργείων.txt': 'Julian: Untitled Letter about the Argives'
        }
        
        for filename, name in julian_mapping.items():
            filepath = os.path.join(julian_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    manuscripts[name] = f.read()
    
    return manuscripts

def create_similarity_heatmap_like_original(results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    manuscript_names = results['manuscript_names']
    similarity_matrices = results['similarity_matrices']
    
    if 'cosine' in similarity_matrices:
        sim_matrix = similarity_matrices['cosine']
        metric_name = 'Cosine Similarity'
    else:
        sim_matrix = list(similarity_matrices.values())[0]
        metric_name = 'Similarity'
    
    print(f"Creating charts for {len(manuscript_names)} manuscripts")
    print(f"Similarity matrix shape: {sim_matrix.shape}")
    
    stats_data = []
    for i, manuscript in enumerate(manuscript_names):
        row_similarities = sim_matrix[i, :]
        other_similarities = np.concatenate([row_similarities[:i], row_similarities[i+1:]])
        
        max_sim_idx = np.argmax(other_similarities)
        if max_sim_idx >= i:
            max_sim_idx += 1
        
        stats_data.append({
            'Manuscript': manuscript,
            'Mean Similarity': other_similarities.mean(),
            'Max Similarity': other_similarities.max(),
            'Min Similarity': other_similarities.min(),
            'Std Similarity': other_similarities.std(),
            'Most Similar To': manuscript_names[max_sim_idx],
            'Max Similarity Value': other_similarities.max()
        })
    
    stats_df = pd.DataFrame(stats_data)
    stats_df = stats_df.sort_values('Mean Similarity', ascending=False)
    
    csv_file = os.path.join(output_dir, 'cluster0_real_similarities.csv')
    stats_df.to_csv(csv_file, index=False)
    
    report_file = os.path.join(output_dir, 'cluster0_detailed_similarity_report.txt')
    with open(report_file, 'w') as f:
        f.write("CLUSTER 0 DETAILED SIMILARITY ANALYSIS\\n")
        f.write("=====================================\\n\\n")
        f.write(f"Analysis of {len(manuscript_names)} manuscripts in Cluster 0\\n")
        f.write(f"Based on {sim_matrix.shape[1]} linguistic features\\n\\n")
        
        f.write("TOP 10 MOST SIMILAR MANUSCRIPT PAIRS:\\n")
        f.write("-" * 40 + "\\n")
        
        pairs = []
        for i in range(len(manuscript_names)):
            for j in range(i+1, len(manuscript_names)):
                pairs.append({
                    'Manuscript 1': manuscript_names[i],
                    'Manuscript 2': manuscript_names[j],
                    'Similarity': sim_matrix[i, j]
                })
        
        pairs_df = pd.DataFrame(pairs)
        top_pairs = pairs_df.nlargest(10, 'Similarity')
        
        for _, pair in top_pairs.iterrows():
            f.write(f"{pair['Manuscript 1']:30} ↔ {pair['Manuscript 2']:30} : {pair['Similarity']:.4f}\\n")
        
        f.write("\\n\\nMANUSCRIPT SIMILARITY STATISTICS:\\n")
        f.write("-" * 40 + "\\n")
        for _, row in stats_df.iterrows():
            f.write(f"\\n{row['Manuscript']}:\\n")
            f.write(f"  Mean Similarity: {row['Mean Similarity']:.4f}\\n")
            f.write(f"  Most Similar To: {row['Most Similar To']} ({row['Max Similarity']:.4f})\\n")
            f.write(f"  Range: {row['Min Similarity']:.4f} to {row['Max Similarity']:.4f}\\n")
            f.write(f"  Std Deviation: {row['Std Similarity']:.4f}\\n")
    
    plt.figure(figsize=(14, 12))
    
    mask = np.triu(np.ones_like(sim_matrix, dtype=bool), k=1)
    
    ax = sns.heatmap(sim_matrix,
                     xticklabels=manuscript_names,
                     yticklabels=manuscript_names,
                     annot=True,
                     fmt='.3f',
                     cmap='RdYlBu_r',
                     center=0.5,
                     square=True,
                     mask=mask,
                     cbar_kws={'label': 'Similarity Score'},
                     annot_kws={'size': 8})
    
    plt.title(f'Cluster 0 Similarity Matrix\\n{metric_name} - Real Linguistic Features from Greek Manuscripts', 
              fontsize=16, fontweight='bold', pad=20)
    plt.xlabel('Manuscripts', fontsize=12)
    plt.ylabel('Manuscripts', fontsize=12)
    plt.xticks(rotation=45, ha='right', fontsize=10)
    plt.yticks(rotation=0, fontsize=10)
    plt.tight_layout()
    
    heatmap_file = os.path.join(output_dir, 'cluster0_similarity_heatmap.png')
    plt.savefig(heatmap_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    plt.figure(figsize=(16, 14))
    plt.axis('tight')
    plt.axis('off')
    
    display_data = stats_df[['Manuscript', 'Mean Similarity', 'Max Similarity', 'Most Similar To']].round(3)
    
    table = plt.table(cellText=display_data.values,
                     colLabels=display_data.columns,
                     cellLoc='center',
                     loc='center',
                     bbox=[0, 0, 1, 1])
    
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.5)
    
    for i in range(len(display_data.columns)):
        table[(0, i)].set_facecolor('#2E86AB')
        table[(0, i)].set_text_props(weight='bold', color='white')
    
    for i in range(1, len(display_data) + 1):
        for j in range(len(display_data.columns)):
            if i % 2 == 0:
                table[(i, j)].set_facecolor('#F8F9FA')
    
    plt.title('Cluster 0: ALL 26 Manuscript Similarity Statistics\\n(Based on Real Linguistic Features from Greek Texts)', 
              fontsize=16, fontweight='bold', pad=20)
    
    table_file = os.path.join(output_dir, 'cluster0_similarity_statistics_table.png')
    plt.savefig(table_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    create_feature_similarities_chart(results, output_dir)
    
    print(f"\\nComplete Cluster 0 analysis finished!")
    print(f"Results saved to: {output_dir}/")
    print(f"CSV data: {csv_file}")
    print(f"Detailed report: {report_file}")
    print(f"Heatmap: {heatmap_file}")
    print(f"Statistics table: {table_file}")
    
    return stats_df

def create_feature_similarities_chart(results, output_dir):
    try:
        feature_matrices = results['feature_matrices']
        manuscript_names = results['manuscript_names']
        
        if len(feature_matrices) > 0:
            X = np.vstack(feature_matrices)
            
            feature_vars = np.var(X, axis=0)
            top_feature_indices = np.argsort(feature_vars)[-20:]
            
            plt.figure(figsize=(12, 8))
            
            top_features_data = X[:, top_feature_indices]
            
            sns.heatmap(top_features_data,
                       yticklabels=manuscript_names,
                       xticklabels=[f'Feature {i+1}' for i in top_feature_indices],
                       cmap='viridis',
                       cbar_kws={'label': 'Feature Value'})
            
            plt.title('Top 20 Most Discriminative Features Across Cluster 0 Manuscripts', 
                      fontsize=14, fontweight='bold')
            plt.xlabel('Linguistic Features')
            plt.ylabel('Manuscripts')
            plt.xticks(rotation=45)
            plt.yticks(rotation=0)
            plt.tight_layout()
            
            feature_file = os.path.join(output_dir, 'cluster0_feature_similarities.png')
            plt.savefig(feature_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            print(f"Feature analysis: {feature_file}")
            
    except Exception as e:
        print(f"Could not create feature chart: {e}")

def run_complete_analysis():
    print("Loading ALL manuscripts from original analysis...")
    manuscripts = load_all_manuscripts()
    
    cluster0_data = {name: text for name, text in manuscripts.items() 
                     if name in CLUSTER_0_MANUSCRIPTS and len(text.strip()) > 50}
    
    print(f"\\nFound {len(cluster0_data)} out of {len(CLUSTER_0_MANUSCRIPTS)} Cluster 0 manuscripts:")
    for name in sorted(cluster0_data.keys()):
        print(f"  ✓ {name} ({len(cluster0_data[name])} chars)")
    
    missing = set(CLUSTER_0_MANUSCRIPTS) - set(cluster0_data.keys())
    if missing:
        print(f"\\nMissing manuscripts:")
        for name in sorted(missing):
            print(f"  ✗ {name}")
    
    if len(cluster0_data) < 10:
        print("\\nWarning: Found fewer manuscripts than expected!")
        print("This may be due to missing data files.")
    
    print(f"\\nRunning NLP analysis on {len(cluster0_data)} manuscripts...")
    comparator = MultipleManuscriptComparison(use_advanced_nlp=False)
    
    try:
        processed_manuscripts = {}
        for name, text in cluster0_data.items():
            print(f"Processing {name}...")
            preprocessed = comparator.preprocessor.preprocess(text)
            preprocessed['nlp_features'] = {}
            processed_manuscripts[name] = preprocessed
        
        print("\\nExtracting linguistic features...")
        features_data = comparator.extract_features(processed_manuscripts)
        
        print("Calculating similarity matrices...")
        similarities = comparator.similarity_calculator.calculate_multiple_similarities(
            comparator.feature_matrices, comparator.manuscript_names
        )
        
        return {
            'manuscript_names': comparator.manuscript_names,
            'similarity_matrices': similarities,
            'features_data': features_data,
            'feature_matrices': comparator.feature_matrices
        }
        
    except Exception as e:
        print(f"Error during analysis: {e}")
        import traceback
        traceback.print_exc()
        return None

def main():
    print("COMPLETE CLUSTER 0 SIMILARITY ANALYSIS")
    print("=" * 50)
    
    results = run_complete_analysis()
    
    if results is None:
        print("Analysis failed. Check errors above.")
        return
    
    output_dir = "cluster0_similarity_analysis"
    stats_df = create_similarity_heatmap_like_original(results, output_dir)
    
    print(f"\\n{'='*50}")
    print("CLUSTER 0 ANALYSIS COMPLETE")
    print(f"{'='*50}")
    print(f"Analyzed {len(results['manuscript_names'])} manuscripts")
    print(f"Generated similarity matrices with {results['similarity_matrices']['cosine'].shape[1]} features")
    
    print("\\nTop 5 most cohesive manuscripts:")
    top5 = stats_df.head()[['Manuscript', 'Mean Similarity', 'Most Similar To']]
    print(top5.to_string(index=False))
    
    print(f"\\nAll results saved to: {output_dir}/")

if __name__ == "__main__":
    main() 