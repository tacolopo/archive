#!/usr/bin/env python3
"""
Fixed Greek analysis with proper clustering parameters.
"""

import os
import glob
from src import MultipleManuscriptComparison

def main():
    """Run FIXED Greek analysis with proper cluster range."""
    print(" RUNNING FIXED GREEK ANALYSIS")
    print("=" * 50)
    print("🔧 Fixes applied:")
    print("  • Cluster range: 2-25 (was 2-8)")
    print("  • More thorough testing")
    print("  • Better parameter validation")
    
    # Collect manuscripts (same as before)
    manuscripts = {}
    
    # Paul's letters from cleaned data
    paul_dir = "data/Cleaned_Paul_Texts/Merged_Paul_Texts"
    if os.path.exists(paul_dir):
        for file_path in glob.glob(os.path.join(paul_dir, "*.txt")):
            filename = os.path.basename(file_path)
            book_name = filename.replace('.txt', '')
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:
                    manuscripts[f"Paul_{book_name}"] = content
    
    # Non-Pauline texts
    nonpauline_dir = "data/Non-Pauline Texts/Merged_NonPauline_Texts"
    if os.path.exists(nonpauline_dir):
        for file_path in glob.glob(os.path.join(nonpauline_dir, "*.txt")):
            filename = os.path.basename(file_path)
            book_name = filename.replace('.txt', '')
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:
                    manuscripts[f"NonPauline_{book_name}"] = content
    
    # Julian's letters
    julian_dir = "data/Julian"
    if os.path.exists(julian_dir):
        for file_path in glob.glob(os.path.join(julian_dir, "*.txt")):
            filename = os.path.basename(file_path)
            letter_name = filename.replace('.txt', '')
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:
                    manuscripts[f"Julian_{letter_name}"] = content
    
    print(f" Collected {len(manuscripts)} manuscripts")
    
    if len(manuscripts) < 5:
        print(" Not enough manuscripts for analysis")
        return False
    
    # Run analysis with FIXED parameters
    analyzer = MultipleManuscriptComparison()
    
    manuscript_texts = list(manuscripts.values())
    manuscript_names = list(manuscripts.keys())
    
    results = analyzer.run_complete_analysis_from_texts(
        manuscript_texts=manuscript_texts,
        manuscript_names=manuscript_names,
        output_dir="fixed_greek_analysis_results",
        n_clusters_range=(2, 25)  # FIXED: Much wider range!
    )
    
    if results:
        print(" Fixed Greek analysis completed successfully!")
        print(f" Results saved to: fixed_greek_analysis_results/")
        
        # Print comparison
        optimal = results.get('optimal_clustering', {})
        print(f" Optimal clusters: {optimal.get('n_clusters', 'N/A')}")
        print(f" Silhouette score: {optimal.get('silhouette_score', 'N/A'):.3f}")
        
        return True
    else:
        print(" Fixed analysis failed")
        return False

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
