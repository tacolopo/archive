#!/usr/bin/env python3

import sys
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any
import pickle

sys.path.append('src')

from multi_comparison import MultipleManuscriptComparison
from similarity import SimilarityCalculator

CLUSTER_0_MANUSCRIPTS = [
    "1 Corinthians", "1 John", "1 Peter", "1 Thessalonians", "1 Timothy",
    "2 Corinthians", "2 John", "2 Peter", "2 Thessalonians", "2 Timothy",
    "3 John", "Galatians", "Hebrews", "James", "Jude",
    "Julian: Letter Fragment", "Julian: To Dionysius", "Julian: To Libanius the Sophist",
    "Julian: To Sarapion the Most Illustrious", "Julian: To the Same Person",
    "Julian: Untitled Letter about the Argives", "Philemon", "Philippians",
    "Revelation", "Romans", "Titus"
]

def load_manuscript_data():
    manuscripts = {}
    
    pauline_dir = "data/Cleaned_Paul_Texts"
    if os.path.exists(pauline_dir):
        for filename in os.listdir(pauline_dir):
            if filename.endswith('_read.txt'):
                filepath = os.path.join(pauline_dir, filename)
                book_name = extract_book_name(filename)
                if book_name:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        manuscripts[book_name] = f.read()
    
    julian_dir = "data/Julian_backup"
    if os.path.exists(julian_dir):
        for filename in os.listdir(julian_dir):
            if filename.endswith('.txt'):
                filepath = os.path.join(julian_dir, filename)
                julian_name = create_julian_name(filename)
                if julian_name:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        manuscripts[julian_name] = f.read()
    
    nt_dir = "data/Non-Pauline Texts"
    if os.path.exists(nt_dir):
        for filename in os.listdir(nt_dir):
            if filename.endswith('_read.txt'):
                filepath = os.path.join(nt_dir, filename)
                book_name = extract_book_name(filename)
                if book_name and book_name in CLUSTER_0_MANUSCRIPTS:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        manuscripts[book_name] = f.read()
    
    return manuscripts

def extract_book_name(filename):
    book_mapping = {
        'grcsbl_075_ROM': 'Romans',
        'grcsbl_076_1CO': '1 Corinthians',
        'grcsbl_077_2CO': '2 Corinthians',
        'grcsbl_078_GAL': 'Galatians',
        'grcsbl_079_EPH': 'Ephesians',
        'grcsbl_080_PHP': 'Philippians',
        'grcsbl_081_COL': 'Colossians',
        'grcsbl_082_1TH': '1 Thessalonians',
        'grcsbl_083_2TH': '2 Thessalonians',
        'grcsbl_084_1TI': '1 Timothy',
        'grcsbl_085_2TI': '2 Timothy',
        'grcsbl_086_TIT': 'Titus',
        'grcsbl_087_PHM': 'Philemon',
        'grcsbl_088_HEB': 'Hebrews',
        'grcsbl_089_JAS': 'James',
        'grcsbl_090_1PE': '1 Peter',
        'grcsbl_091_2PE': '2 Peter',
        'grcsbl_092_1JN': '1 John',
        'grcsbl_093_2JN': '2 John',
        'grcsbl_094_3JN': '3 John',
        'grcsbl_095_JUD': 'Jude',
        'grcsbl_096_REV': 'Revelation'
    }
    
    for pattern, name in book_mapping.items():
        if pattern in filename:
            return name
    return None

def create_julian_name(filename):
    julian_mapping = {
        'Διονυσίῳ.txt': 'Julian: To Dionysius',
        'Λιβανίῳ σοφιστῇ καὶ κοιαίστωρι.txt': 'Julian: To Libanius the Sophist',
        'Σαραπίωνι τῷ λαμπροτάτῳ.txt': 'Julian: To Sarapion the Most Illustrious',
        'Τῷ αὐτῷ.txt': 'Julian: To the Same Person',
        'φραγμεντυμ επιστολαε.txt': 'Julian: Letter Fragment',
        'Ἀνεπίγραφος ὑπὲρ Ἀργείων.txt': 'Julian: Untitled Letter about the Argives'
    }
    
    return julian_mapping.get(filename, None)

def run_actual_analysis():
    print("Loading manuscript data...")
    manuscripts = load_manuscript_data()
    
    cluster0_manuscripts = {name: text for name, text in manuscripts.items() 
                           if name in CLUSTER_0_MANUSCRIPTS}
    
    print(f"Found {len(cluster0_manuscripts)} Cluster 0 manuscripts:")
    for name in sorted(cluster0_manuscripts.keys()):
        print(f"  - {name}")
    
    if len(cluster0_manuscripts) < 5:
        print("Warning: Not enough manuscripts found. Check data directories.")
        return None
    
    print("\nInitializing analysis system...")
    comparator = MultipleManuscriptComparison(use_advanced_nlp=True)
    
    print("\nRunning analysis on Cluster 0 manuscripts...")
    manuscript_texts = list(cluster0_manuscripts.values())
    manuscript_names = list(cluster0_manuscripts.keys())
    
    try:
        processed_manuscripts = {}
        for name, text in cluster0_manuscripts.items():
            print(f"Processing {name}...")
            preprocessed = comparator.preprocessor.preprocess(text)
            
            if comparator.use_advanced_nlp and comparator.advanced_processor:
                try:
                    nlp_features = comparator.advanced_processor.process_document(
                        preprocessed['normalized_text']
                    )
                    preprocessed['nlp_features'] = nlp_features
                except Exception as e:
                    print(f"Warning: Advanced NLP failed for {name}: {e}")
                    preprocessed['nlp_features'] = {}
            else:
                preprocessed['nlp_features'] = {}
            
            processed_manuscripts[name] = preprocessed
        
        print("\nExtracting features...")
        features_data = comparator.extract_features(processed_manuscripts)
        
        print("\nCalculating similarity matrices...")
        similarities = comparator.similarity_calculator.calculate_multiple_similarities(
            comparator.feature_matrices, comparator.manuscript_names
        )
        
        return {
            'manuscripts': cluster0_manuscripts,
            'processed_manuscripts': processed_manuscripts,
            'features_data': features_data,
            'similarity_matrices': similarities,
            'manuscript_names': comparator.manuscript_names,
            'feature_matrices': comparator.feature_matrices
        }
        
    except Exception as e:
        print(f"Error during analysis: {e}")
        import traceback
        traceback.print_exc()
        return None

def create_real_similarity_analysis(analysis_results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    similarity_matrices = analysis_results['similarity_matrices']
    manuscript_names = analysis_results['manuscript_names']
    
    if 'cosine' in similarity_matrices:
        similarity_matrix = similarity_matrices['cosine']
    elif 'euclidean' in similarity_matrices:
        similarity_matrix = similarity_matrices['euclidean']
    else:
        print("No similarity matrix found!")
        return
    
    print(f"Using similarity matrix of shape: {similarity_matrix.shape}")
    print(f"Manuscript names: {manuscript_names}")
    
    stats_data = []
    
    for i, manuscript in enumerate(manuscript_names):
        similarities = similarity_matrix[i, :]
        similarities_no_self = np.concatenate([similarities[:i], similarities[i+1:]])
        
        max_idx = np.argmax(similarities_no_self)
        if max_idx >= i:
            max_idx += 1
        
        stats_data.append({
            'Manuscript': manuscript,
            'Mean Similarity': similarities_no_self.mean(),
            'Max Similarity': similarities_no_self.max(),
            'Min Similarity': similarities_no_self.min(),
            'Std Similarity': similarities_no_self.std(),
            'Most Similar To': manuscript_names[max_idx]
        })
    
    stats_df = pd.DataFrame(stats_data)
    stats_df = stats_df.sort_values('Mean Similarity', ascending=False)
    
    csv_file = os.path.join(output_dir, 'real_cluster0_similarity_statistics.csv')
    stats_df.to_csv(csv_file, index=False)
    
    plt.figure(figsize=(14, 12))
    
    mask = np.triu(np.ones_like(similarity_matrix, dtype=bool), k=1)
    sns.heatmap(similarity_matrix, 
                xticklabels=manuscript_names,
                yticklabels=manuscript_names,
                annot=True, 
                fmt='.3f',
                cmap='RdYlBu_r',
                center=0.5,
                square=True,
                mask=mask,
                cbar_kws={'label': 'Similarity Score'})
    
    plt.title('Cluster 0: Real Similarity Matrix\n(Based on Actual Linguistic Features)', 
              fontsize=16, fontweight='bold', pad=20)
    plt.xlabel('Manuscripts', fontsize=12)
    plt.ylabel('Manuscripts', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    
    heatmap_file = os.path.join(output_dir, 'real_cluster0_similarity_heatmap.png')
    plt.savefig(heatmap_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Real similarity analysis saved to: {output_dir}")
    print(f"Similarity statistics: {csv_file}")
    print(f"Similarity heatmap: {heatmap_file}")
    
    return stats_df

def main():
    print("REAL CLUSTER 0 SIMILARITY ANALYSIS")
    print("=" * 50)
    print("Loading actual manuscript data and running linguistic analysis...")
    
    analysis_results = run_actual_analysis()
    
    if analysis_results is None:
        print("Analysis failed. Check error messages above.")
        return
    
    output_dir = "real_cluster0_analysis"
    stats_df = create_real_similarity_analysis(analysis_results, output_dir)
    
    if stats_df is not None:
        print("\nTop 10 most similar manuscripts in Cluster 0:")
        print(stats_df.head(10)[['Manuscript', 'Mean Similarity', 'Most Similar To']].to_string(index=False))
        
        print(f"\nAnalysis complete! Results saved to: {output_dir}/")
        print("This analysis uses REAL linguistic features, not simulated data.")

if __name__ == "__main__":
    main() 