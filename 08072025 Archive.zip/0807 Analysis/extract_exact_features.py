#!/usr/bin/env python3
"""
Extract the EXACT 1,208-dimensional feature vectors from the Python analysis
"""

import os
import sys
import numpy as np

# Add src to path
sys.path.append('/home/user/greek-manuscript-comparison/src')
sys.path.append('/home/user/greek-manuscript-comparison')

def collect_manuscripts():
    """Collect manuscripts exactly like the original analysis"""
    book_name_mapping = {
        '070_MAT': 'Matthew', '071_MRK': 'Mark', '072_LUK': 'Luke', '073_JHN': 'John', '074_ACT': 'Acts',
        '075_ROM': 'Romans', '076_1CO': '1Corinthians', '077_2CO': '2Corinthians', '078_GAL': 'Galatians',
        '079_EPH': 'Ephesians', '080_PHP': 'Philippians', '081_COL': 'Colossians', '082_1TH': '1Thessalonians',
        '083_2TH': '2Thessalonians', '084_1TI': '1Timothy', '085_2TI': '2Timothy', '086_TIT': 'Titus',
        '087_PHM': 'Philemon', '088_HEB': 'Hebrews', '089_JAS': 'James', '090_1PE': '1Peter', '091_2PE': '2Peter',
        '092_1JN': '1John', '093_2JN': '2John', '094_3JN': '3John', '095_JUD': 'Jude', '096_REV': 'Revelation'
    }
    
    julian_name_mapping = {
        'Διονυσίῳ.txt': 'Julian: To Dionysius',
        'Λιβανίῳ σοφιστῇ καὶ κοιαίστωρι.txt': 'Julian: To Libanius the Sophist',
        'Σαραπίωνι τῷ λαμπροτάτῳ.txt': 'Julian: To Sarapion the Most Illustrious',
        'Τῷ αὐτῷ.txt': 'Julian: To the Same Person',
        'φραγμεντυμ επιστολαε.txt': 'Julian: Letter Fragment',
        'Ἀνεπίγραφος ὑπὲρ Ἀργείων.txt': 'Julian: Untitled Letter about the Argives'
    }
    
    manuscripts = {}
    data_dir = "/home/user/greek-manuscript-comparison/data"
    
    # Process biblical texts
    chapter_files = {}
    for root, dirs, files in os.walk(data_dir):
        if 'Julian' in root:
            continue
        for file in files:
            if file.endswith('.txt') and '_read' in file:
                full_path = os.path.join(root, file)
                name = file.replace('_read.txt', '').replace('grcsbl_', '')
                parts = name.split('_')
                if len(parts) >= 2:
                    book_key = f"{parts[0]}_{parts[1]}"
                    if book_key not in chapter_files:
                        chapter_files[book_key] = []
                    chapter_files[book_key].append(full_path)
    
    # Combine chapters
    for book_key, file_paths in chapter_files.items():
        file_paths.sort(key=lambda x: int(x.split('_')[-2]))
        combined_text = ""
        for file_path in file_paths:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    chapter_text = f.read().strip()
                    if chapter_text:
                        combined_text += chapter_text + "\n\n"
            except Exception as e:
                print(f"Warning: Could not read {file_path}: {e}")
        
        if combined_text.strip():
            readable_name = book_name_mapping.get(book_key, book_key)
            manuscripts[readable_name] = combined_text.strip()
    
    # Process Julian's letters
    julian_dir = os.path.join(data_dir, 'Julian')
    if os.path.exists(julian_dir):
        for file in os.listdir(julian_dir):
            if file.endswith('.txt'):
                file_path = os.path.join(julian_dir, file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            readable_name = julian_name_mapping.get(file, f"Julian: {file.replace('.txt', '')}")
                            manuscripts[readable_name] = text
                except Exception as e:
                    print(f"Warning: Could not read Julian letter {file}: {e}")
    
    return manuscripts

def main():
    print("=== EXTRACTING EXACT PYTHON FEATURES ===")
    
    # Import after setting up the environment
    try:
        from src.multi_comparison import MultipleManuscriptComparison
        
        # Collect manuscripts
        manuscripts = collect_manuscripts()
        print(f"Found {len(manuscripts)} manuscripts")
        
        # Initialize the EXACT same system as original analysis
        comparator = MultipleManuscriptComparison(use_advanced_nlp=True)
        
        # Run the EXACT same analysis pipeline to get the features
        manuscript_texts = list(manuscripts.values())
        manuscript_names = list(manuscripts.keys())
        
        print("Running exact feature extraction pipeline...")
        
        # Step 1: Preprocess (exact same as original)
        processed_manuscripts = {}
        for i, text in enumerate(manuscript_texts):
            name = manuscript_names[i]
            processed_manuscripts[name] = comparator.preprocessor.preprocess(text)
        
        # Step 2: Extract features (exact same as original)
        features_data = comparator.extract_features(processed_manuscripts)
        
        # Now we have the EXACT feature matrices
        feature_matrices = comparator.feature_matrices
        names = comparator.manuscript_names
        
        print(f"Extracted EXACT features: {len(feature_matrices)} manuscripts x {len(feature_matrices[0])} dimensions")
        
        # Save as CSV for Stylo
        with open('/home/user/Stylo/exact_python_features.csv', 'w') as f:
            # Header with manuscript names
            f.write(',' + ','.join(f'"{name}"' for name in names) + '\n')
            
            # Features (transpose so manuscripts are columns)
            feature_array = np.array(feature_matrices).T
            for i, row in enumerate(feature_array):
                f.write(f'"feature_{i}",' + ','.join(map(str, row)) + '\n')
        
        print("✓ EXACT Python features exported to: /home/user/Stylo/exact_python_features.csv")
        print(f"✓ Shape: {len(feature_matrices[0])} features x {len(names)} manuscripts")
        print("✓ Ready for Stylo analysis with IDENTICAL features!")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()