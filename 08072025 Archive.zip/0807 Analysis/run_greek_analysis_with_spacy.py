#!/usr/bin/env python3
"""
Enhanced Greek NLP Analysis Script with PROPER SpaCy Integration

This script performs data-driven clustering analysis of Greek manuscripts
using advanced NLP features with the CORRECTED Ancient Greek spaCy model.
"""

import os
import glob
from src import MultipleManuscriptComparison

def collect_manuscripts_by_book(data_dir: str) -> dict:
    """
    Collect and combine manuscript files by complete books/letters, including Julian's letters.
    
    Args:
        data_dir: Path to data directory containing text files
        
    Returns:
        Dictionary mapping book names to combined text content
    """
    # Mapping from codes to readable names for biblical texts
    book_name_mapping = {
        '070_MAT': 'Matthew',
        '071_MRK': 'Mark', 
        '072_LUK': 'Luke',
        '073_JHN': 'John',
        '074_ACT': 'Acts',
        '075_ROM': 'Romans',
        '076_1CO': '1 Corinthians',
        '077_2CO': '2 Corinthians',
        '078_GAL': 'Galatians',
        '079_EPH': 'Ephesians',
        '080_PHP': 'Philippians',
        '081_COL': 'Colossians',
        '082_1TH': '1 Thessalonians',
        '083_2TH': '2 Thessalonians',
        '084_1TI': '1 Timothy',
        '085_2TI': '2 Timothy',
        '086_TIT': 'Titus',
        '087_PHM': 'Philemon',
        '088_HEB': 'Hebrews',
        '089_JAS': 'James',
        '090_1PE': '1 Peter',
        '091_2PE': '2 Peter',
        '092_1JN': '1 John',
        '093_2JN': '2 John',
        '094_3JN': '3 John',
        '095_JUD': 'Jude',
        '096_REV': 'Revelation'
    }
    
    manuscripts = {}
    
    # Process Paul's letters from cleaned texts
    paul_dir = os.path.join(data_dir, "Cleaned_Paul_Texts")
    if os.path.exists(paul_dir):
        print(f"Processing Paul's letters from: {paul_dir}")
        
        # Group files by book code
        book_files = {}
        for file_path in glob.glob(os.path.join(paul_dir, "*.txt")):
            filename = os.path.basename(file_path)
            
            # Extract book code (e.g., "075_ROM" from "grcsbl_075_ROM_01_read.txt")
            parts = filename.split('_')
            if len(parts) >= 3:
                book_code = f"{parts[1]}_{parts[2]}"
                if book_code not in book_files:
                    book_files[book_code] = []
                book_files[book_code].append(file_path)
        
        # Combine files for each book
        for book_code, files in book_files.items():
            book_name = book_name_mapping.get(book_code, book_code)
            combined_text = ""
            
            # Sort files to ensure consistent order
            files.sort()
            
            for file_path in files:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            combined_text += text + "\n"
                except Exception as e:
                    print(f"Warning: Could not read {file_path}: {e}")
            
            if combined_text.strip():
                manuscripts[f"Paul_{book_name}"] = combined_text.strip()
                print(f"  ✓ Combined {len(files)} chapters for Paul's {book_name}")
    
    # Process Non-Pauline texts
    non_pauline_dir = os.path.join(data_dir, "Non-Pauline Texts")
    if os.path.exists(non_pauline_dir):
        print(f"\nProcessing Non-Pauline texts from: {non_pauline_dir}")
        
        # Group files by book code
        book_files = {}
        for file_path in glob.glob(os.path.join(non_pauline_dir, "*.txt")):
            filename = os.path.basename(file_path)
            
            # Extract book code
            parts = filename.split('_')
            if len(parts) >= 3:
                book_code = f"{parts[1]}_{parts[2]}"
                if book_code not in book_files:
                    book_files[book_code] = []
                book_files[book_code].append(file_path)
        
        # Combine files for each book
        for book_code, files in book_files.items():
            book_name = book_name_mapping.get(book_code, book_code)
            combined_text = ""
            
            # Sort files to ensure consistent order
            files.sort()
            
            for file_path in files:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            combined_text += text + "\n"
                except Exception as e:
                    print(f"Warning: Could not read {file_path}: {e}")
            
            if combined_text.strip():
                manuscripts[f"NonPauline_{book_name}"] = combined_text.strip()
                print(f"  ✓ Combined {len(files)} chapters for {book_name}")
    
    # Process Julian's letters
    julian_dir = os.path.join(data_dir, "Julian")
    if os.path.exists(julian_dir):
        print(f"\nProcessing Julian's letters from: {julian_dir}")
        
        for file_path in glob.glob(os.path.join(julian_dir, "*.txt")):
            filename = os.path.basename(file_path)
            letter_name = os.path.splitext(filename)[0]
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read().strip()
                    if text:
                        manuscripts[f"Julian_{letter_name}"] = text
                        print(f"  ✓ Added Julian's {letter_name}")
            except Exception as e:
                print(f"Warning: Could not read {file_path}: {e}")
    
    return manuscripts

def main():
    """Main analysis function with PROPER Ancient Greek spaCy integration."""
    print("  ENHANCED GREEK MANUSCRIPT ANALYSIS WITH PROPER SPACY")
    print("=" * 70)
    print(" CRITICAL: Now using CORRECT Ancient Greek spaCy model!")
    print(" Model: grc_odycy_joint_sm (Ancient Greek)")
    print(" SpaCy integration: ENABLED in both AdvancedGreekProcessor AND FeatureExtractor")
    print("=" * 70)
    
    try:
        # Test spaCy models before proceeding
        print(" Validating Ancient Greek spaCy model...")
        import spacy
        try:
            nlp_test = spacy.load("grc_odycy_joint_sm")
            print(" Ancient Greek spaCy model validation successful!")
            del nlp_test
        except Exception as e:
            print(f" CRITICAL: Ancient Greek spaCy model not available: {e}")
            print("Please ensure grc_odycy_joint_sm is properly installed.")
            return False
        
        # Collect manuscripts from multiple sources
        print("\n Collecting manuscripts from multiple sources...")
        manuscripts = collect_manuscripts_by_book("data")
        
        if not manuscripts:
            print(" No manuscripts found! Check data directory structure.")
            return False
        
        print(f"\n Found {len(manuscripts)} complete manuscripts:")
        for name in sorted(manuscripts.keys()):
            word_count = len(manuscripts[name].split())
            print(f"  • {name}: {word_count:,} words")
        
        # Initialize the comparison system
        print("\n🔧 Initializing enhanced NLP analysis system...")
        print(" Ancient Greek spaCy integration enabled")
        comparator = MultipleManuscriptComparison()
        
        # Prepare data for analysis
        manuscript_texts = list(manuscripts.values())
        manuscript_names = list(manuscripts.keys())
        
        # Run the complete analysis with CORRECTED spaCy models
        print("\n Running complete enhanced clustering analysis...")
        print("📝 Features extracted with PROPER Ancient Greek linguistic analysis:")
        print("  • Vocabulary richness with Greek morphology")
        print("  • Ancient Greek function words and particles")
        print("  • POS tagging with Ancient Greek grammar")
        print("  • Dependency parsing for Ancient Greek syntax")
        print("  • Named entity recognition for ancient texts")
        print("  • Morphological analysis (subjunctive, optative, participles)")
        print("  • Sentence complexity for Ancient Greek")
        print("  • Character and word n-grams")
        print("  • TF-IDF features")
        print("  • Semantic embeddings with Greek BERT")
        
        results = comparator.run_complete_analysis_from_texts(
            manuscript_texts=manuscript_texts,
            manuscript_names=manuscript_names,
            output_dir="greek_analysis_with_spacy_results"
        )
        
        print("\n" + "="*70)
        print("🎉 ENHANCED GREEK ANALYSIS WITH SPACY COMPLETE!")
        print("="*70)
        print(f" Results saved to: greek_analysis_with_spacy_results/")
        print(" Generated outputs:")
        print("  • Clustering analysis report with spaCy features")
        print("  • Methodology documentation")
        print("  • Multi-dimensional scaling visualization")
        print("  • Hierarchical clustering dendrograms")
        print("  • Distance matrices")
        print("  • Feature importance analysis")
        
        print("\n Analysis Features (NOW WITH PROPER SPACY):")
        print("   Ancient Greek POS tagging")
        print("   Dependency parsing for Greek syntax")
        print("   Named entity recognition")
        print("   Greek morphological analysis")
        print("   Sentence segmentation")
        print("   Lemmatization for Ancient Greek")
        print("   Vocabulary richness measures")
        print("   Function word analysis")
        print("   Semantic embeddings")
        print("   Multiple clustering algorithms")
        print("   Comprehensive validation metrics")
        print("   Feature selection and dimensionality reduction")
        
        print("\n🆚 COMPARISON WITH PREVIOUS RESULTS:")
        print("   Old results: enhanced_clustering_results/ (preserved)")
        print("   New results: greek_analysis_with_spacy_results/ (with proper spaCy)")
        print("\nCheck both directories to compare the impact of proper spaCy integration!")
        
        return True
        
    except Exception as e:
        print(f"\n Error during analysis: {e}")
        print("This might be due to missing dependencies or spaCy model issues.")
        print("Check the error details above and ensure Ancient Greek spaCy model is installed.")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    if not success:
        print(" Analysis failed - exiting with error code")
        exit(1)